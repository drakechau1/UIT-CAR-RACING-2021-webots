# pal-webots-competition-organizer

This repository is part of the [2021 IROS-RSJ Robotic Challenge for Young Students](https://roboticslab-uc3m.github.io/challenge-iros2021)!


## Results

You can check the results of the competition at: <https://pal-admin.github.io/pal-webots-competition-organizer>
