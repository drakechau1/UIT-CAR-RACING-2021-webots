"""Test controller."""

# You may need to import some classes of the controller module. Ex:
#  from controller import Robot, Motor, DistanceSensor
from controller import Robot
from controller import Motor
from controller import DistanceSensor
from controller import Camera
from controller import LED
from controller import Supervisor
import math

# create the Robot instance
robot = Robot()

# get the time step of the current world
timestep = 32

# You should insert a getDevice-like function in order to get the
# instance of a device of the robot. Something like:
#  motor = robot.getDevice('motorname')
#  ds = robot.getDevice('dsname')
#  ds.enable(timestep)
robot.step(timestep)
        
# Camera
cam = robot.getDevice("camera")
cam.enable(64)
    
# Leff motor
lm = robot.getDevice("left wheel motor")
lm.setPosition(float("inf"))
lm.setVelocity(0)
lm_max_speed = lm.getMaxVelocity()/2

# Right motor
rm = robot.getDevice("right wheel motor")
rm.setPosition(float("inf"))
rm.setVelocity(0)
rm_max_speed = rm.getMaxVelocity()/2

# Sensors
NB_GROUND_SENS = 8
gs = []
gsNames = [
    'gs0', 'gs1', 'gs2', 'gs3',
    'gs4', 'gs5', 'gs6', 'gs7'
]
for i in range(NB_GROUND_SENS):
    gs.append(robot.getDevice(gsNames[i]))
    gs[i].enable(timestep)

# LEDs
NB_LEDS = 5
leds = []
led_Names = [
    'led0', 'led1', 'led2', 'led3', 'led4'
]
for i in range(NB_LEDS):
    leds.append(robot.getDevice(led_Names[i]))

# Waiting for completing initialization
initTime = robot.getTime()
while robot.step(timestep) != -1:
    if (robot.getTime() - initTime) * 1000.0 > 200:
        break

### Private Functions ###
# You should declare all your functions to get data, process data and
# control your robot outputs such as: motors, LEDs, etc in this field.

# NOP = -1
# MID = 0
# LEFT  = 1
# RIGHT = 2
# FULL_SIGNAL  = 3
# BLANK_SIGNAL = 4

# Điều chỉnh tốc độ phù hợp
#MAX_SPEED = 20 

threshold = [345, 345, 345, 345, 345, 345, 345, 345]
preFilted = 0b00000000
prepreFilted = 0b00000000

# Biến lưu giá trị tỉ lệ tốc độ của động cơ
# left_ratio = 0.0
# right_ratio = 0.0
# Function to read data from ground sensors
def getSensors():
    gsValues = []
    for i in range(NB_GROUND_SENS):
        gsValues.append(gs[i].getValue())
    #print(*gsValues, sep = '\t')
    return gsValues
def ReadSensors():
    gsValues = []
    filted = 0x00
    for i in range(NB_GROUND_SENS):
        gsValues.append(gs[i].getValue())
        if gsValues[i] > threshold[i]:
            filted |= (0x01 << (NB_GROUND_SENS - i - 1))
    # print(*gsValues, sep = '\t')
    return filted
# Function to control LEDs
def LED_Alert():
    if (robot.getTime() - initTime)*1000 % 3000 >= 2000:
        leds[1].set(not(leds[1].get()))
        #for i in range(NB_LEDS):
            #leds[i].set(not(leds[i].get()))
    return

# Function to control Motors
def trai (filted,gsValues):
     # cua trai 0123456
    if(filted == 0b11111110 and gs[7].getValue()>147):
        lm.setVelocity((0 / 1000.0) * lm_max_speed)
        rm.setVelocity((50 / 1000.0) * rm_max_speed)
    # cua trai 0123456
    elif(filted == 0b11111110):
        lm.setVelocity((0 / 1000.0) * lm_max_speed)
        rm.setVelocity((100 / 1000.0) * rm_max_speed)
    # vuong trai 012345
    # special
    elif(gs[0].getValue()>550 and gs[0].getValue()<1030 and gs[1].getValue()>560 and gs[1].getValue()<1030 and gs[2].getValue()>560 and gs[2].getValue()<1030 and gs[3].getValue()>560 and gs[3].getValue()<1010 and gs[4].getValue()>550 and gs[4].getValue()<1010 and gs[5].getValue()>550 and gs[5].getValue()<1025 and gs[6].getValue()>28 and gs[6].getValue()<140 and gs[7].getValue()>37 and gs[7].getValue()<140):
        lm.setVelocity((0 / 1000.0) * lm_max_speed)
        rm.setVelocity((100 / 1000.0) * rm_max_speed)
    # cua trai 012345
    elif(filted == 0b11111100 and gs[6].getValue()>94):
        lm.setVelocity((2 / 1000.0) * lm_max_speed)
        rm.setVelocity((45 / 1000.0) * rm_max_speed)

    # vuong trai 0123
    # special
    elif(gs[0].getValue()>550 and gs[0].getValue()<775 and gs[1].getValue()>560 and gs[1].getValue()<900 and gs[2].getValue()>550 and gs[2].getValue()<800 and gs[3].getValue()>540 and gs[3].getValue()<800 and gs[4].getValue()>95 and gs[4].getValue()<165 and gs[5].getValue()>95 and gs[5].getValue()<150 and gs[6].getValue()>100 and gs[6].getValue()<150 and gs[7].getValue()>100 and gs[7].getValue()<150):
        lm.setVelocity((0 / 1000.0) * lm_max_speed)
        rm.setVelocity((80 / 1000.0) * rm_max_speed)
    # trai 0123
    elif(gs[0].getValue()>495 and gs[0].getValue()<525 and gs[1].getValue()>460 and gs[1].getValue()<490 and gs[2].getValue()>1000 and gs[2].getValue()<1030 and gs[3].getValue()>985 and gs[3].getValue()<1010 and gs[4].getValue()>335 and gs[4].getValue()<365 and gs[5].getValue()>275 and gs[5].getValue()<305 and gs[6].getValue()>215 and gs[6].getValue()<245 and gs[7].getValue()>155 and gs[7].getValue()<185):
        lm.setVelocity((0 / 1000.0) * lm_max_speed)
        rm.setVelocity((80 / 1000.0) * rm_max_speed)
    #cua vuong trai 0123
    elif(filted == 0b11110000):
        lm.setVelocity((7 / 1000.0) * lm_max_speed)
        rm.setVelocity((50 / 1000.0) * rm_max_speed)

    #khac
    # vuong trai 01234
    elif(gs[0].getValue()>565 and gs[0].getValue()<800 and gs[1].getValue()>565 and gs[1].getValue()<760 and gs[2].getValue()>570 and gs[2].getValue()<750 and gs[3].getValue()>575 and gs[3].getValue()<730 and gs[4].getValue()>570 and gs[4].getValue()<700 and gs[5].getValue()>95 and gs[5].getValue()<150 and gs[6].getValue()>85 and gs[6].getValue()<150 and gs[7].getValue()>80 and gs[7].getValue()>150):
        lm.setVelocity((0 / 1000.0) * lm_max_speed)
        rm.setVelocity((100 / 1000.0) * rm_max_speed)
    #cua vuong trai 01234
    #special
    elif(filted == 0b11111000):
        lm.setVelocity((0 / 1000.0) * lm_max_speed)
        rm.setVelocity((55 / 1000.0) * rm_max_speed)

    # trai 01
    elif(gs[0].getValue()>800 and gs[0].getValue()<850 and gs[1].getValue()>800 and gs[1].getValue()<850 and gs[2].getValue()>150 and gs[2].getValue()<175 and gs[3].getValue()>150 and gs[3].getValue()<175 and gs[4].getValue()>140 and gs[4].getValue()<175 and gs[5].getValue()>140 and gs[5].getValue()<175 and gs[6].getValue()>135 and gs[6].getValue()<165 and gs[7].getValue()>135 and gs[7].getValue()<157):
        lm.setVelocity((5 / 1000.0) * lm_max_speed)
        rm.setVelocity((45 / 1000.0) * rm_max_speed)
    # vuong trai 01
    elif(gs[0].getValue()>950 and gs[0].getValue()<1030 and gs[1].getValue()>950 and gs[1].getValue()<1030 and gs[2].getValue()>200 and gs[2].getValue()<250 and gs[3].getValue()>195 and gs[3].getValue()<225 and gs[4].getValue()>174 and gs[4].getValue()<215 and gs[5].getValue()>135 and gs[5].getValue()<170 and gs[6].getValue()>100 and gs[6].getValue()<140 and gs[7].getValue()>60 and gs[7].getValue()<120):
        lm.setVelocity((20 / 1000.0) * lm_max_speed)
        rm.setVelocity((55 / 1000.0) * rm_max_speed)
    # cua trai 01
    elif(gs[0].getValue()>345 and gs[0].getValue()<880 and gs[1].getValue()>346 and gs[1].getValue()<850 and filted == 0b11000000 and gs[7].getValue()>72):
        lm.setVelocity((0 / 1000.0) * lm_max_speed)
        rm.setVelocity((95 / 1000.0) * rm_max_speed)
    # cua trai 01
    elif(filted == 0b11000000 and gs[2].getValue()>18 and gs[7].getValue()>80):
        lm.setVelocity((10 / 1000.0) * lm_max_speed)
        rm.setVelocity((80 / 1000.0) * rm_max_speed)

    # trai 12
    elif(gs[0].getValue()>85 and gs[0].getValue()<105 and gs[1].getValue()>445 and gs[1].getValue()<465 and gs[2].getValue()>435 and gs[2].getValue()<465 and gs[3].getValue()>75 and gs[3].getValue()<100 and gs[4].getValue()>70 and gs[4].getValue()<100 and gs[5].getValue()>70 and gs[5].getValue()<95 and gs[6].getValue()>65 and gs[6].getValue()<95 and gs[7].getValue()>65 and gs[7].getValue()<95):
        lm.setVelocity((0 / 1000.0) * lm_max_speed)
        rm.setVelocity((80 / 1000.0) * rm_max_speed)
    # cua trai 12
    elif(filted == 0b01100000 and gs[7].getValue()>55):
        lm.setVelocity((0 / 1000.0) * lm_max_speed)
        rm.setVelocity((85 / 1000.0) * rm_max_speed)

    # cua trai 2
    elif(gs[0].getValue()>65 and gs[0].getValue()<95 and gs[1].getValue()>115 and gs[1].getValue()<145 and gs[2].getValue()>940 and gs[2].getValue()<975 and gs[3].getValue()>230 and gs[3].getValue()<260 and gs[4].getValue()>275 and gs[4].getValue()<305 and gs[5].getValue()>315 and gs[5].getValue()<340 and gs[6].getValue()>355 and gs[6].getValue()<380 and gs[7].getValue()>390 and gs[7].getValue()<420):
       lm.setVelocity((5 / 1000.0) * lm_max_speed)
       rm.setVelocity((50 / 1000.0) * rm_max_speed)
    # cua trai 2
    elif(filted == 0b00100000):
        lm.setVelocity((0 / 1000.0) * lm_max_speed)
        rm.setVelocity((60 / 1000.0) * rm_max_speed)

       #1 vuong  trai 012
    elif(gs[0].getValue()>510 and gs[0].getValue()<800 and gs[1].getValue()>595 and gs[1].getValue()<905 and gs[2].getValue()>595 and gs[2].getValue()<850 and gs[3].getValue()>115 and gs[3].getValue()<200 and gs[4].getValue()>110 and gs[4].getValue()<200 and gs[5].getValue()>105 and gs[5].getValue()<205 and gs[6].getValue()>95 and gs[6].getValue()<220 and gs[7].getValue()>95 and gs[7].getValue()<225):
        lm.setVelocity((0 / 1000.0) * lm_max_speed)
        rm.setVelocity((90 / 1000.0) * rm_max_speed)
    # cua trai 012
    elif(filted == 0b11100000 and gs[3].getValue()>14):
        lm.setVelocity((5 / 1000.0) * lm_max_speed)
        rm.setVelocity((65 / 1000.0) * rm_max_speed)
        
    # cua trai 2567
    elif(filted == 0b00100111):
        lm.setVelocity((5 / 1000.0) * lm_max_speed)
        rm.setVelocity((60 / 1000.0) * rm_max_speed)
    
    
     #cua trai 234
    elif(gs[0].getValue()>45 and gs[0].getValue()<140 and gs[1].getValue()>50 and gs[1].getValue()<370 and gs[2].getValue()>450 and gs[2].getValue()<650  and gs[3].getValue()>650 and gs[3].getValue()<950 and gs[4].getValue()>840 and gs[4].getValue()<1020 and gs[5].getValue()>150 and gs[5].getValue()<300 and gs[6].getValue()>200 and gs[6].getValue()<350 and gs[7].getValue()>250 and gs[7].getValue()<360):
        lm.setVelocity((30 / 1000.0) * lm_max_speed)
        rm.setVelocity((65 / 1000.0) * rm_max_speed)
    #cua trai 234
    elif(gs[0].getValue()>15 and gs[0].getValue()<205 and gs[1].getValue()>50 and gs[1].getValue()<190 and gs[2].getValue()>450 and gs[2].getValue()<700  and gs[3].getValue()>530 and gs[3].getValue()<720 and gs[4].getValue()>520 and gs[4].getValue()<895 and gs[5].getValue()>100 and gs[5].getValue()<250 and gs[6].getValue()>85 and gs[6].getValue()<295 and gs[7].getValue()>60 and gs[7].getValue()<330):
        lm.setVelocity((0 / 1000.0) * lm_max_speed)
        rm.setVelocity((100 / 1000.0) * rm_max_speed)
    # cua trai 234
    elif(filted == 0b00111000):
        lm.setVelocity((45 / 1000.0) * lm_max_speed)
        rm.setVelocity((50 / 1000.0) * rm_max_speed)
        
    #cua trai 23
    elif(gs[0].getValue()>100 and gs[0].getValue()<150 and gs[1].getValue()>100 and gs[1].getValue()<150 and gs[2].getValue()>530 and gs[2].getValue()<570  and gs[3].getValue()>525 and gs[3].getValue()<565 and gs[4].getValue()>120 and gs[4].getValue()>160 and gs[5].getValue()>120 and gs[5].getValue()<160 and gs[6].getValue()>120 and gs[6].getValue()<160 and gs[7].getValue()>120 and gs[7].getValue()<160):
        lm.setVelocity((30 / 1000.0) * lm_max_speed)
        rm.setVelocity((70 / 1000.0) * rm_max_speed)
    #cua trai 23
    elif(gs[0].getValue()>100 and gs[0].getValue()<150 and gs[1].getValue()>111 and gs[1].getValue()<150 and gs[2].getValue()>425 and gs[2].getValue()<650  and gs[3].getValue()>425 and gs[3].getValue()<660 and gs[4].getValue()>100 and gs[4].getValue()<150 and gs[5].getValue()>100 and gs[5].getValue()<150 and gs[6].getValue()<100 and gs[6].getValue()<150 and gs[7].getValue()>100 and gs[7].getValue()<150):
        lm.setVelocity((30 / 1000.0) * lm_max_speed)
        rm.setVelocity((74 / 1000.0) * rm_max_speed)   
    # cua trai 23
    elif(filted == 0b00110000):
        lm.setVelocity((20 / 1000.0) * lm_max_speed)
        rm.setVelocity((53 / 1000.0) * rm_max_speed)
    
    # cua trai 1
    elif(filted == 0b01000000 and gs[7].getValue()>115):
        lm.setVelocity((0 / 1000.0) * lm_max_speed)
        rm.setVelocity((50 / 1000.0) * rm_max_speed)
    
    # cua trai 123
    elif(filted == 0b01110000):
        lm.setVelocity((0 / 1000.0) * lm_max_speed)
        rm.setVelocity((70 / 1000.0) * rm_max_speed)
    # cua trai 1234
    elif(filted == 0b01111000):
        lm.setVelocity((0 / 1000.0) * lm_max_speed)
        rm.setVelocity((60 / 1000.0) * rm_max_speed)
    # cua trai 0
    elif(filted == 0b10000000 and gs[1].getValue()>111):
        lm.setVelocity((0 / 1000.0) * lm_max_speed)
        rm.setVelocity((100 / 1000.0) * rm_max_speed)
    # cua trai 0
    elif(filted == 0b10000000 and gs[1].getValue()>36):
        lm.setVelocity((0 / 1000.0) * lm_max_speed)
        rm.setVelocity((70 / 1000.0) * rm_max_speed)
    # cua trai 0
    elif( gs[0].getValue()<750 and filted == 0b10000000):
        lm.setVelocity((0 / 1000.0) * lm_max_speed)
        rm.setVelocity((100 / 1000.0) * rm_max_speed)
    # cua trai 3
    if(gs[0].getValue()>140 and gs[0].getValue()<180 and gs[1].getValue()>130 and gs[1].getValue()<170 and gs[2].getValue()>120 and gs[2].getValue()<160 and gs[3].getValue()>530 and gs[3].getValue()<570 and gs[4].getValue()>105 and gs[4].getValue()<145 and gs[5].getValue()>100 and gs[5].getValue()<140 and gs[6].getValue()>90 and gs[6].getValue()<130 and gs[7].getValue()>80 and gs[7].getValue()<120):
        lm.setVelocity((45 / 1000.0) * lm_max_speed)
        rm.setVelocity((50 / 1000.0) * rm_max_speed)
    #cua trai 3
    elif(filted == 0b00010000 and gs[7].getValue()>28):
        lm.setVelocity((25 / 1000.0) * lm_max_speed)
        rm.setVelocity((45 / 1000.0) * rm_max_speed)
    
    #cua trai 0125
    elif(filted == 0b11100100):
        lm.setVelocity((0 / 1000.0) * lm_max_speed)
        rm.setVelocity((100 / 1000.0) * rm_max_speed)
    # cua trai 0124
    elif(filted == 0b11101000):
        lm.setVelocity((0 / 1000.0) * lm_max_speed)
        rm.setVelocity((100 / 1000.0) * rm_max_speed)
    
    # trai 0123567
    elif(filted == 0b11110111):
        lm.setVelocity((0 / 1000.0) * lm_max_speed)
        rm.setVelocity((90 / 1000.0) * rm_max_speed)
    # trai 01235
    elif(filted == 0b11110111):
        lm.setVelocity((0 / 1000.0) * lm_max_speed)
        rm.setVelocity((80 / 1000.0) * rm_max_speed)
    # trai 37
    elif(filted == 0b00010001 and gs[0].getValue()>66):
        lm.setVelocity((0 / 1000.0) * lm_max_speed)
        rm.setVelocity((100 / 1000.0) * rm_max_speed)
    # trai 013567
    elif(filted == 0b11010111):
        lm.setVelocity((0 / 1000.0) * lm_max_speed)
        rm.setVelocity((1000 / 1000.0) * rm_max_speed)
        
    
    
    return
    
def phai(filted,gsValues):
    # vuong phai 567
    if(gs[0].getValue()>100 and gs[0].getValue()<345 and gs[1].getValue()>100 and gs[1].getValue()<345 and gs[2].getValue()>100 and gs[2].getValue()<340 and gs[3].getValue()>100 and gs[3].getValue()<320 and gs[4].getValue()>100 and gs[4].getValue()<285 and gs[5].getValue()>550 and gs[5].getValue()<1045 and gs[6].getValue()>550 and gs[6].getValue()<890 and gs[7].getValue()>540 and gs[7].getValue()<670):
        lm.setVelocity((100 / 1000.0) * lm_max_speed)
        rm.setVelocity((0 / 1000.0) * rm_max_speed)
    # cua phai 567
    elif(filted == 0b00000111):
        lm.setVelocity((70 / 1000.0) * lm_max_speed)
        rm.setVelocity((15 / 1000.0) * rm_max_speed)

    # vuong phai 34567
    elif(gs[0].getValue()>0 and gs[0].getValue()<290 and gs[1].getValue()>0 and gs[1].getValue()<280 and gs[2].getValue()>60 and gs[2].getValue()<255 and gs[3].getValue()>450 and gs[3].getValue()<1035 and gs[4].getValue()>500 and gs[4].getValue()<980 and gs[5].getValue()>500 and gs[5].getValue()<1020 and gs[6].getValue()>475 and gs[6].getValue()<1030 and gs[7].getValue()>360 and gs[7].getValue()<1030):
        lm.setVelocity((95 / 1000.0) * lm_max_speed)
        rm.setVelocity((-10 / 1000.0) * rm_max_speed)
    # cua phai 34567
    elif(filted == 0b00011111 and gs[3].getValue()<1013):
        lm.setVelocity((75 / 1000.0) * lm_max_speed)
        rm.setVelocity((15 / 1000.0) * rm_max_speed)

    # vuong phai 345
    elif(gs[0].getValue()>20 and gs[0].getValue()<140 and gs[1].getValue()>50 and gs[1].getValue()<140 and gs[2].getValue()>80 and gs[2].getValue()<140 and gs[3].getValue()>510 and gs[3].getValue()<610 and gs[4].getValue()>570 and gs[4].getValue()<710 and gs[5].getValue()>570 and gs[5].getValue()<855 and gs[6].getValue()>100 and gs[6].getValue()<250 and gs[7].getValue()>100 and gs[7].getValue()<270):
        lm.setVelocity((80 / 1000.0) * lm_max_speed)
        rm.setVelocity((0 / 1000.0) * rm_max_speed)
    # cua phai 345
    elif(filted == 0b00011100 and gs[0].getValue()>119):
        lm.setVelocity((50 / 1000.0) * lm_max_speed)
        rm.setVelocity((5 / 1000.0) * rm_max_speed)
        
    # cua phai 456
    elif(gs[0].getValue()>80 and gs[0].getValue()<140 and gs[1].getValue()>85 and gs[1].getValue()<130 and gs[2].getValue()>90 and gs[2].getValue()<135 and gs[3].getValue()>90 and gs[3].getValue()<145 and gs[4].getValue()>450 and gs[4].getValue()<500 and gs[5].getValue()>475 and gs[5].getValue()<515 and gs[6].getValue()>495 and gs[6].getValue()<530 and gs[7].getValue()>110 and gs[7].getValue()<150):
        lm.setVelocity((100 / 1000.0) * lm_max_speed)
        rm.setVelocity((0 / 1000.0) * rm_max_speed)
    # cua phai 456
    elif(filted == 0b00001110):
        lm.setVelocity((50 / 1000.0) * lm_max_speed)
        rm.setVelocity((20 / 1000.0) * rm_max_speed)

    # cua phai 4567
    elif(gs[0].getValue()>80 and gs[0].getValue()<140 and gs[1].getValue()>85 and gs[1].getValue()<155 and gs[2].getValue()>90 and gs[2].getValue()<150 and gs[3].getValue()>90 and gs[3].getValue()<155 and gs[4].getValue()>530 and gs[4].getValue()<695 and gs[5].getValue()>510 and gs[5].getValue()<700 and gs[6].getValue()>510 and gs[6].getValue()<725 and gs[7].getValue()>540 and gs[7].getValue()<800):
        lm.setVelocity((100 / 1000.0) * lm_max_speed)
        rm.setVelocity((0 / 1000.0) * rm_max_speed)
    # cua phai 4567
    elif(filted == 0b00001111):
        lm.setVelocity((45 / 1000.0) * lm_max_speed)
        rm.setVelocity((0 / 1000.0) * rm_max_speed)

    # phai 056
    elif(gs[0].getValue()>1000 and gs[0].getValue()<1030 and gs[1].getValue()>20 and gs[1].getValue()<60 and gs[2].getValue()>50 and gs[2].getValue()<100 and gs[3].getValue()>100 and gs[3].getValue()<140 and gs[4].getValue()>125 and gs[4].getValue()<175 and gs[5].getValue()>920 and gs[5].getValue()<965 and gs[6].getValue()>970 and gs[6].getValue()<1010 and gs[7].getValue()>225 and gs[7].getValue()<275):
        lm.setVelocity((80 / 1000.0) * lm_max_speed)
        rm.setVelocity((5 / 1000.0) * rm_max_speed)
    # vuong phai 017
    elif(gs[0].getValue()>340 and gs[0].getValue()<390 and gs[1].getValue()>300 and gs[1].getValue()<350 and gs[2].getValue()>270 and gs[2].getValue()<310 and gs[3].getValue()>225 and gs[3].getValue()<280 and gs[4].getValue()>200 and gs[4].getValue()<250 and gs[5].getValue()>140 and gs[5].getValue()<200 and gs[6].getValue()>100 and gs[6].getValue()<150 and gs[7].getValue()>310 and gs[7].getValue()<380):
        lm.setVelocity((80 / 1000.0) * lm_max_speed)
        rm.setVelocity((0 / 1000.0) * rm_max_speed)
    # nay la trai 017
    elif(gs[0].getValue()>470 and gs[0].getValue()<530 and gs[1].getValue()>400 and gs[1].getValue()<460 and gs[2].getValue()>320 and gs[2].getValue()<360 and gs[3].getValue()>250 and gs[3].getValue()<290 and gs[4].getValue()>160 and gs[4].getValue()<200 and gs[5].getValue()>80 and gs[5].getValue()<120 and gs[6].getValue()>0 and gs[6].getValue()<50 and gs[7].getValue()>980 and gs[7].getValue()<1020):
        lm.setVelocity((0 / 1000.0) * lm_max_speed)
        rm.setVelocity((200 / 1000.0) * rm_max_speed)
        
    # cua phai 56
    elif(filted == 0b00000110):
        lm.setVelocity((76 / 1000.0) * lm_max_speed)
        rm.setVelocity((25 / 1000.0) * rm_max_speed)
    # cua phai 7    
    elif(filted == 0b00000001 and gs[1].getValue()>117):
        lm.setVelocity((95 / 1000.0) * lm_max_speed)
        rm.setVelocity((0 / 1000.0) * rm_max_speed)
    
    # cua phai 67
    elif(filted == 0b00000011 and gs[1].getValue()>81):
        lm.setVelocity((75 / 1000.0) * lm_max_speed)
        rm.setVelocity((5 / 1000.0) * rm_max_speed)
    # cua phai 6
    elif(filted == 0b00000010):
        lm.setVelocity((80 / 1000.0) * lm_max_speed)
        rm.setVelocity((10 / 1000.0) * rm_max_speed)
    
    # cua phai 45
    elif(gs[0].getValue()>114 and gs[0].getValue()<190 and gs[1].getValue()>100 and gs[1].getValue()<170 and gs[2].getValue()>100 and gs[2].getValue()<165  and gs[3].getValue()>125 and gs[3].getValue()<160 and gs[4].getValue()>420 and gs[4].getValue()<625 and gs[5].getValue()>385 and gs[5].getValue()<685 and gs[6].getValue()>85 and gs[6].getValue()<350 and gs[7].getValue()>75 and gs[7].getValue()<285):
        lm.setVelocity((90 / 1000.0) * lm_max_speed)
        rm.setVelocity((0 / 1000.0) * rm_max_speed)
    # cua phai 45
    elif(filted == 0b00001100):
        lm.setVelocity((70 / 1000.0) * lm_max_speed)
        rm.setVelocity((38 / 1000.0) * rm_max_speed)
    # cua phai 467
    elif(filted == 0b00001011):
        lm.setVelocity((60 / 1000.0) * lm_max_speed)
        rm.setVelocity((10 / 1000.0) * rm_max_speed)
    # cua phai 4
    elif(gs[0].getValue()>0 and gs[0].getValue()<155 and gs[1].getValue()>20 and gs[1].getValue()<155 and gs[2].getValue()>75 and gs[2].getValue()<155  and gs[3].getValue()>125 and gs[3].getValue()<160 and gs[4].getValue()>740 and gs[4].getValue()<800 and gs[5].getValue()>200 and gs[5].getValue()<250 and gs[6].getValue()>230 and gs[6].getValue()<280 and gs[7].getValue()>270 and gs[7].getValue()<320):
        lm.setVelocity((60 / 1000.0) * lm_max_speed)
        rm.setVelocity((10 / 1000.0) * rm_max_speed)
    # cua phai 4
    elif(filted == 0b00001000 and gs[1].getValue()>152 and gs[4].getValue()<997):
        lm.setVelocity((42 / 1000.0) * lm_max_speed)
        rm.setVelocity((30 / 1000.0) * rm_max_speed)
    # cua phai 4
    elif(filted == 0b00001000 and gs[1].getValue()>98 and gs[4].getValue()<997):
        lm.setVelocity((40 / 1000.0) * lm_max_speed)
        rm.setVelocity((25 / 1000.0) * rm_max_speed)
    # cua phai 4
    elif(filted == 0b00001000 and gs[4].getValue()<997 and gs[7].getValue()>100):
        lm.setVelocity((42 / 1000.0) * lm_max_speed)
        rm.setVelocity((25 / 1000.0) * rm_max_speed)
    
    
    
    
    # cua phai 3456
    elif(filted == 0b00011110):
        lm.setVelocity((80 / 1000.0) * lm_max_speed)
        rm.setVelocity((2 / 1000.0) * rm_max_speed)
    
    # cua phai 24567
    elif(filted == 0b00101111):
        lm.setVelocity((60 / 1000.0) * lm_max_speed)
        rm.setVelocity((0 / 1000.0) * rm_max_speed)
    
    
    # cua phai 234567
    elif(filted == 0b00111111 and gs[1].getValue()<382):
        lm.setVelocity((100 / 1000.0) * lm_max_speed)
        rm.setVelocity((0 / 1000.0) * rm_max_speed)
    # phai 01267
    elif(filted == 0b11100011):
        lm.setVelocity((40 / 1000.0) * lm_max_speed)
        rm.setVelocity((20 / 1000.0) * rm_max_speed)
    #cua phai 347
    elif(gs[0].getValue()>0 and gs[0].getValue()<275 and gs[1].getValue()>0 and gs[1].getValue()<240 and gs[2].getValue()>125 and gs[2].getValue()<240  and gs[3].getValue()>550 and gs[3].getValue()<645 and gs[4].getValue()>400 and gs[4].getValue()<450 and gs[5].getValue()>0 and gs[5].getValue()<80 and gs[6].getValue()>0 and gs[6].getValue()<50 and gs[7].getValue()>950 and gs[7].getValue()<1030):
        lm.setVelocity((55 / 1000.0) * lm_max_speed)
        rm.setVelocity((35 / 1000.0) * rm_max_speed)
    # phai 1367
    elif(filted == 0b01010011):
        lm.setVelocity((100 / 1000.0) * lm_max_speed)
        rm.setVelocity((0 / 1000.0) * rm_max_speed)
    # phai 1234567
    elif(filted == 0b01111111):
        lm.setVelocity((100 / 1000.0) * lm_max_speed)
        rm.setVelocity((0 / 1000.0) * rm_max_speed)
    # cua phai 5
    elif(gs[0].getValue()>10 and gs[0].getValue()<40 and gs[1].getValue()>30 and gs[1].getValue()<90 and gs[2].getValue()>80 and gs[2].getValue()<120 and gs[3].getValue()>120 and gs[3].getValue()<160 and gs[4].getValue()>160 and gs[4].getValue()<200 and gs[5].getValue()>900 and gs[5].getValue()<940 and gs[6].getValue()>220 and gs[6].getValue()<265 and gs[7].getValue()>250 and gs[7].getValue()<300):
        lm.setVelocity((60 / 1000.0) * lm_max_speed)
        rm.setVelocity((0 / 1000.0) * rm_max_speed)    
    # cua phai 5
    elif(filted == 0b00000100):
        lm.setVelocity((50 / 1000.0) * lm_max_speed)
        rm.setVelocity((4 / 1000.0) * rm_max_speed)
    # phai 367
    elif(gs[0].getValue()>100 and gs[0].getValue()<150 and gs[1].getValue()>100 and gs[1].getValue()<150 and gs[2].getValue()>110 and gs[2].getValue()<150  and gs[3].getValue()>500 and gs[3].getValue()<540 and gs[4].getValue()>110 and gs[4].getValue()>150 and gs[5].getValue()>110 and gs[5].getValue()<160 and gs[6].getValue()>500 and gs[6].getValue()<540 and gs[7].getValue()>490 and gs[7].getValue()<530):
        lm.setVelocity((100 / 1000.0) * lm_max_speed)
        rm.setVelocity((0 / 1000.0) * rm_max_speed)
    # phai 367
    elif(filted == 0b00010011):
        lm.setVelocity((55 / 1000.0) * lm_max_speed)
        rm.setVelocity((40 / 1000.0) * rm_max_speed)
    # phai 045
    elif(filted == 0b10001100):
        lm.setVelocity((60 / 1000.0) * lm_max_speed)
        rm.setVelocity((3 / 1000.0) * rm_max_speed)
    # phai 457
    elif(filted == 0b00001101):
        lm.setVelocity((0 / 1000.0) * lm_max_speed)
        rm.setVelocity((0 / 1000.0) * rm_max_speed)
    return
    
def thang(filted,gsValues):
    # chinh giua
    if(filted == 0b00011000):
        lm.setVelocity((57 / 1000.0) * lm_max_speed)
        rm.setVelocity((57 / 1000.0) * rm_max_speed)
    # giua 01234567
    elif(filted == 0b11111111 and gs[3].getValue()<1021):
        lm.setVelocity((78 / 1000.0) * lm_max_speed)
        rm.setVelocity((78 / 1000.0) * rm_max_speed)
    # giua 35
    elif(filted == 0b00010100):
        lm.setVelocity((45 / 1000.0) * lm_max_speed)
        rm.setVelocity((45 / 1000.0) * rm_max_speed)
    # giua 3467
    elif(filted == 0b00011011):
        lm.setVelocity((45 / 1000.0) * lm_max_speed)
        rm.setVelocity((45 / 1000.0) * rm_max_speed)

    return
    
   
def Line_Following_Module(filted,gsValues):
    # if (robot.getTime() - initTime) * 1000.0 < 1000:
        # lm.setVelocity((100 / 1000.0) * lm_max_speed)
        # rm.setVelocity((100 / 1000.0) * rm_max_speed)
    # else:
        # lm.setVelocity((0 / 1000.0) * lm_max_speed)
        # rm.setVelocity((0 / 1000.0) * rm_max_speed)
        
    if(filted == 0b00011000 or filted == 0b11111111 or filted == 0b00010100 or filted == 0b00011011):
        thang(filted,gsValues)
    elif(filted == 0b00000111 or filted == 0b00011111 or filted == 0b00001101 or filted == 0b10001100 or filted == 0b00011100 or filted == 0b00001110 or filted == 0b00001111 or filted == 0b10000110 or filted == 0b11000001 or filted == 0b00000110 or filted == 0b00000001 or filted == 0b00000100 or filted == 0b00000011 or filted == 0b00001100 or filted == 0b00001011 or filted == 0b00001000 or filted == 0b00011110 or filted == 0b00101111 or filted == 0b00111111 or filted == 0b11100011 or filted == 0b00011001 or filted == 0b01010011 or filted == 0b01111111 or filted == 0b00010011 or filted == 0b00000010): 
        phai(filted,gsValues)
    elif(filted == 0b11111110 or filted == 0b11010111 or filted == 0b11111100 or filted == 0b11110000 or filted == 0b11111000 or filted == 0b11000000 or filted == 0b01100000 or filted == 0b00100000 or filted == 0b11100000 or filted == 0b00111000 or filted == 0b00110000 or filted == 0b01000000 or filted == 0b01110000 or filted == 0b01111000 or filted == 0b10000000 or filted == 0b00010000 or filted == 0b11100100 or filted == 0b11101000 or filted == 0b11110111 or filted == 0b11110111 or filted == 0b00010001):
        trai(filted,gsValues)
    
    return
    
def Lineline(filted,preFilted,prepreFilted,gsValues):
        # 01234 3
    if(filted == 0b11111000 and preFilted == 0b00010000):
        lm.setVelocity((30 / 1000.0) * lm_max_speed)
        rm.setVelocity((30 / 1000.0) * rm_max_speed)
    # 01234 34 3
    if(filted == 0b11111000 and preFilted == 0b00011000 and prepreFilted == 0b00010000):
        lm.setVelocity((30 / 1000.0) * lm_max_speed)
        rm.setVelocity((30 / 1000.0) * rm_max_speed)
    # 01234567 4
    elif(filted == 0b11111111 and preFilted == 0b00001000):
        lm.setVelocity((0 / 1000.0) * lm_max_speed)
        rm.setVelocity((100 / 1000.0) * rm_max_speed)
    # 01234567 34 45
    elif(filted == 0b11111111 and preFilted == 0b00011000 and prepreFilted == 0b00001100):
        lm.setVelocity((1000 / 1000.0) * lm_max_speed)
        rm.setVelocity((0 / 1000.0) * rm_max_speed)
    # 01234567 3 34
    elif(filted == 0b11111111 and preFilted == 0b00010000 and prepreFilted == 0b00011000):
        lm.setVelocity((0 / 1000.0) * lm_max_speed)
        rm.setVelocity((500 / 1000.0) * rm_max_speed)
    # 01234567 01234567 01234567
    elif(filted == 0b11111111 and preFilted == 0b11111111 and prepreFilted == 0b11111111):
        lm.setVelocity((0 / 1000.0) * lm_max_speed)
        rm.setVelocity((0 / 1000.0) * rm_max_speed)
    # trang 4 
    elif(filted == 0b00000000 and preFilted == 0b00001000):
        lm.setVelocity((55 / 1000.0) * lm_max_speed)
        rm.setVelocity((55 / 1000.0) * rm_max_speed)
    # trang 3 
    elif(filted == 0b00000000 and preFilted == 0b00010000):
        lm.setVelocity((55 / 1000.0) * lm_max_speed)
        rm.setVelocity((55 / 1000.0) * rm_max_speed)        
    # 34567 3456
    elif(filted == 0b00011111 and preFilted == 0b00011110):
        lm.setVelocity((40 / 1000.0) * lm_max_speed)
        rm.setVelocity((40 / 1000.0) * rm_max_speed)
    # 34567 34567
    elif(filted == 0b00011111 and preFilted == 0b00011111):
        lm.setVelocity((20 / 1000.0) * lm_max_speed)
        rm.setVelocity((20 / 1000.0) * rm_max_speed)
    # 34567 34 4
    elif(filted == 0b00011111 and preFilted == 0b00011000 and prepreFilted == 0b00001000):
        lm.setVelocity((30 / 1000.0) * lm_max_speed)
        rm.setVelocity((30 / 1000.0) * rm_max_speed)
    # 34567 45 4
    elif(filted == 0b00011111 and preFilted == 0b00001100 and prepreFilted == 0b00001000):
        lm.setVelocity((30 / 1000.0) * lm_max_speed)
        rm.setVelocity((30 / 1000.0) * rm_max_speed)
    # 3456 4
    elif(filted == 0b00011110 and preFilted == 0b00001000):
        lm.setVelocity((30 / 1000.0) * lm_max_speed)
        rm.setVelocity((30 / 1000.0) * rm_max_speed)
    # 3456 34 4
    elif(filted == 0b00011110 and preFilted == 0b00011000 and prepreFilted == 0b00001000):
        lm.setVelocity((30 / 1000.0) * lm_max_speed)
        rm.setVelocity((30 / 1000.0) * rm_max_speed)
    # 0123456 56
    elif(filted == 0b11111110 and preFilted == 0b00000110):
        lm.setVelocity((0 / 1000.0) * lm_max_speed)
        rm.setVelocity((100 / 1000.0) * rm_max_speed)
    # 1 01234567 34
    elif(filted == 0b01000000 and preFilted == 0b11111111 and prepreFilted == 0b00011000):
        lm.setVelocity((50 / 1000.0) * lm_max_speed)
        rm.setVelocity((0 / 1000.0) * rm_max_speed)
    # 37 34
    elif(filted == 0b00010001 and preFilted == 0b00011000):
        lm.setVelocity((0 / 1000.0) * lm_max_speed)
        rm.setVelocity((100 / 1000.0) * rm_max_speed)
    # 0346 34 
    elif(filted == 0b10011010 and preFilted == 0b00011000):
        lm.setVelocity((0 / 1000.0) * lm_max_speed)
        rm.setVelocity((100 / 1000.0) * rm_max_speed)    
    # 034 34 3
    elif(filted == 0b10011000 and preFilted == 0b00011000 and prepreFilted == 0b00010000):
        lm.setVelocity((100 / 1000.0) * lm_max_speed)
        rm.setVelocity((0 / 1000.0) * rm_max_speed)      
    # 0145 012 34
    elif(filted == 0b11001100 and preFilted == 0b11100000 and prepreFilted == 0b00011000):
        lm.setVelocity((30 / 1000.0) * lm_max_speed)
        rm.setVelocity((30 / 1000.0) * rm_max_speed)         
    # 7 017 45
    elif(filted == 0b00000001 and preFilted == 0b11000001 and prepreFilted == 0b00001100):
        lm.setVelocity((0 / 1000.0) * lm_max_speed)
        rm.setVelocity((100 / 1000.0) * rm_max_speed)
    return 
# Main loop:
# - perform simulation stegs until Webots is stopping the controller
while robot.step(timestep) != -1:
    # Read the sensors:
    # Enter here functions to read sensor data, like:
    #  val = ds.getValue()
    sensors_Data = getSensors()
    filted = ReadSensors()
    #print(*sensors_Data, sep = '\t')
    # Process sensor data here.
    LED_Alert()
    # Enter here functions to send actuator commands, like:
    #  motor.setPosition(10.0)
    Line_Following_Module(filted,sensors_Data)
    if(filted == 0b11111000 or filted == 0b11111111 or filted == 0b00000000 or filted == 0b00011111 or filted == 0b00011110 or filted == 0b11111110 or filted == 0b01000000 or filted == 0b00010001 or filted == 0b10011010 or filted == 0b10011000 or filted == 0b11001100 or filted == 0b00000001):
        Lineline(filted,preFilted,prepreFilted,sensors_Data)
    prepreFilted = preFilted    
    preFilted = filted
    pass

# Enter here exit cleanup code.
