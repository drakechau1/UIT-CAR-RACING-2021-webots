'use strict';

var otherColor = 0

Blockly.defineBlocksWithJsonArray([  // BEGIN JSON EXTRACT

	{//blockly-demo.appspot.com/static/demos/blockfactory/index.html#6we9tj
    "type": "other_start",
    "message0": "Start",
    "nextStatement": null,
    "colour": otherColor,
    "tooltip": "includes initialization",
    "helpUrl": ""
  },
	{//blockly-demo.appspot.com/static/demos/blockfactory/index.html#cxeb2v
	  "type": "other_end",
	  "message0": "End",
	  "previousStatement": null,
	  "colour": otherColor,
	  "tooltip": "",
	  "helpUrl": ""
	}

]);
